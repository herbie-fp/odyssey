

__device__ void mul(float a, float b, float *res);

__global__ void dot_prod(float *x, float *y, int size);
