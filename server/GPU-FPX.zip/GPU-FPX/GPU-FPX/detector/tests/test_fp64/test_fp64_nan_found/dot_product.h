

//__device__ void mul(double a, double b, double *res);

__global__ void dot_prod(double *x, double *y, int size);
